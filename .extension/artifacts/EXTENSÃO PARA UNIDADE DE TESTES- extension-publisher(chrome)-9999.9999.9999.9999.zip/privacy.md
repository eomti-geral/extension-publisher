# Política de Privacidade para "TESTING" extension-publisher"

Nenhum dado ou informação pessoal é coletado pelo "TESTING" chrome-webstore-upload demo".

## Informações Adicionais

Esta extensão foi desenvolvida exclusivamente para fins de teste dentro deste projeto. Não foi projetada para uso público ou distribuição. Nenhuma funcionalidade desta extensão coleta, armazena ou compartilha dados de usuários.
