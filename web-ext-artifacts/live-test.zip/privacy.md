# Privacy Policy for "TESTING" chrome-webstore-upload demo"

No data or personal information is collected by "TESTING" chrome-webstore-upload demo".

##### Contact

If you have any questions or suggestions regarding this privacy policy, do not hesitate to [contact us](https://github.com/fregante/chrome-webstore-upload/issues/new).
